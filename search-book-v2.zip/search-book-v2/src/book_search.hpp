#ifndef BOOK_SEARCH_HPP
#define BOOK_SEARCH_HPP

#include <string>
#include <vector>

// A single book in the library.
struct Book {
    int id = 0;
    std::string title;
    std::string author;
    std::string isbn;
    std::string category;
    bool is_available = true;
};

// Returns a lowercase copy of `text` (ASCII), used for case-insensitive search.
std::string toLower(const std::string& text);

// Removes spaces from the start and end of `text`.
std::string trim(const std::string& text);

// Search the given books.
//  - `query`    : matched (case-insensitive, partial match) against title,
//                 author and ISBN. An empty query matches every book.
//  - `category` : if not empty, only books of exactly this category
//                 (case-insensitive) are returned.
// Both conditions must be true for a book to be returned.
std::vector<Book> searchBooks(const std::vector<Book>& books,
                              const std::string& query,
                              const std::string& category);

// Turns a list of books into a JSON array string, matching what
// public/script.js expects (title, author, isbn, category, is_available).
std::string booksToJson(const std::vector<Book>& books);

#endif  // BOOK_SEARCH_HPP
