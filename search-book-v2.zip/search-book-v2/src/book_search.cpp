#include "book_search.hpp"

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <sstream>

std::string toLower(const std::string& text) {
    std::string result = text;
    std::transform(result.begin(), result.end(), result.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return result;
}

std::string trim(const std::string& text) {
    const char* spaces = " \t\n\r";
    std::size_t start = text.find_first_not_of(spaces);
    if (start == std::string::npos) return "";
    std::size_t end = text.find_last_not_of(spaces);
    return text.substr(start, end - start + 1);
}

// True if `needle` (already lowercase) appears inside `haystack`.
static bool contains(const std::string& haystack, const std::string& needle) {
    return toLower(haystack).find(needle) != std::string::npos;
}

std::vector<Book> searchBooks(const std::vector<Book>& books,
                              const std::string& query,
                              const std::string& category) {
    const std::string q = toLower(trim(query));
    const std::string cat = toLower(trim(category));

    std::vector<Book> results;
    for (const Book& book : books) {
        // 1) Category filter (exact match, ignoring upper/lower case)
        if (!cat.empty() && toLower(book.category) != cat) continue;

        // 2) Text filter (title OR author OR isbn contains the query)
        if (!q.empty() &&
            !contains(book.title, q) &&
            !contains(book.author, q) &&
            !contains(book.isbn, q)) {
            continue;
        }

        results.push_back(book);
    }
    return results;
}

// Escapes characters that would break a JSON string.
static std::string jsonEscape(const std::string& text) {
    std::ostringstream out;
    for (unsigned char c : text) {
        switch (c) {
            case '"':  out << "\\\""; break;
            case '\\': out << "\\\\"; break;
            case '\n': out << "\\n";  break;
            case '\r': out << "\\r";  break;
            case '\t': out << "\\t";  break;
            default:
                if (c < 0x20) {
                    char buf[8];
                    std::snprintf(buf, sizeof(buf), "\\u%04x", c);
                    out << buf;
                } else {
                    out << c;
                }
        }
    }
    return out.str();
}

std::string booksToJson(const std::vector<Book>& books) {
    std::ostringstream out;
    out << "[";
    for (std::size_t i = 0; i < books.size(); ++i) {
        const Book& b = books[i];
        if (i > 0) out << ",";
        out << "{\"id\":" << b.id
            << ",\"title\":\"" << jsonEscape(b.title) << "\""
            << ",\"author\":\"" << jsonEscape(b.author) << "\""
            << ",\"isbn\":\"" << jsonEscape(b.isbn) << "\""
            << ",\"category\":\"" << jsonEscape(b.category) << "\""
            << ",\"is_available\":" << (b.is_available ? "true" : "false")
            << "}";
    }
    out << "]";
    return out.str();
}
