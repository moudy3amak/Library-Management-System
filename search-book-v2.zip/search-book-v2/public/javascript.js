// View Books page: loads books from the server and handles search + filter.

let searchTimer = null;     // used to wait until the user stops typing
let latestRequestId = 0;    // used to ignore old responses that arrive late

document.addEventListener('DOMContentLoaded', () => fetchBooks());

async function fetchBooks(query = '', category = '') {
    const requestId = ++latestRequestId;

    const grid = document.getElementById('bookGrid');
    const loading = document.getElementById('loading');
    const noResults = document.getElementById('noResults');

    grid.innerHTML = '';
    loading.style.display = 'block';
    noResults.style.display = 'none';

    try {
        const res = await fetch(
            `/api/books?search=${encodeURIComponent(query)}&category=${encodeURIComponent(category)}`
        );
        if (!res.ok) throw new Error(`Server returned ${res.status}`);
        const books = await res.json();

        // A newer search was started while we were waiting: ignore this answer.
        if (requestId !== latestRequestId) return;

        loading.style.display = 'none';

        if (books.length === 0) {
            noResults.style.display = 'block';
            return;
        }

        books.forEach(b => {
            const card = document.createElement('div');
            card.className = 'book-card';
            card.innerHTML = `
                <span class="badge">${escapeHtml(b.category)}</span>
                <h3>${escapeHtml(b.title)}</h3>
                <p><strong>Author:</strong> ${escapeHtml(b.author)}</p>
                <p><strong>ISBN:</strong> ${escapeHtml(b.isbn)}</p>
                <span class="status ${b.is_available ? 'available' : 'borrowed'}">
                    ${b.is_available ? 'Available' : 'Borrowed'}
                </span>
            `;
            grid.appendChild(card);
        });
    } catch (e) {
        if (requestId !== latestRequestId) return;
        loading.style.display = 'none';
        grid.innerHTML = `<p class="error">Error loading books.</p>`;
    }
}

// Called on every key press / category change.
// Waits 300 ms after the last change so we don't send a request per letter.
function handleSearch() {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => {
        const q = document.getElementById('searchInput').value.trim();
        const c = document.getElementById('categoryFilter').value;
        fetchBooks(q, c);
    }, 300);
}

function escapeHtml(text) {
    if (text === null || text === undefined) return '';
    return String(text).replace(/[&<>"']/g, m => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    }[m]));
}
