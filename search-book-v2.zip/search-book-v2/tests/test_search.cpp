#include <cstdlib>
#include <iostream>

#include "../src/book_search.hpp"

static int failures = 0;

#define CHECK(cond)                                                          \
    do {                                                                     \
        if (!(cond)) {                                                       \
            std::cerr << "FAILED line " << __LINE__ << ": " #cond << "\n";   \
            ++failures;                                                      \
        }                                                                    \
    } while (0)

static std::vector<Book> sampleBooks() {
    return {
        {1, "Clean Code", "Robert Martin", "9780132350884", "Technology", true},
        {2, "The Hobbit", "J.R.R. Tolkien", "9780547928227", "Fiction", true},
        {3, "A Brief History of Time", "Stephen Hawking", "9780553380163", "Science", false},
        {4, "Sapiens", "Yuval Harari", "9780062316097", "History", true},
        {5, "Code Complete", "Steve McConnell", "9780735619678", "Technology", true},
    };
}

int main() {
    const auto books = sampleBooks();

    // Empty query + empty category -> everything
    CHECK(searchBooks(books, "", "").size() == 5);

    // Search by title (case-insensitive, partial)
    CHECK(searchBooks(books, "hobbit", "").size() == 1);
    CHECK(searchBooks(books, "HOBBIT", "").size() == 1);
    CHECK(searchBooks(books, "code", "").size() == 2);

    // Search by author
    auto byAuthor = searchBooks(books, "hawking", "");
    CHECK(byAuthor.size() == 1);
    CHECK(byAuthor[0].id == 3);

    // Search by ISBN
    auto byIsbn = searchBooks(books, "9780062316097", "");
    CHECK(byIsbn.size() == 1);
    CHECK(byIsbn[0].title == "Sapiens");

    // Category filter only
    CHECK(searchBooks(books, "", "Technology").size() == 2);
    CHECK(searchBooks(books, "", "technology").size() == 2);

    // Query + category together (both must match)
    CHECK(searchBooks(books, "code", "Technology").size() == 2);
    CHECK(searchBooks(books, "code", "Fiction").empty());

    // Spaces around the query are ignored
    CHECK(searchBooks(books, "   sapiens  ", "").size() == 1);

    // No match
    CHECK(searchBooks(books, "zzzz", "").empty());

    // Empty library
    CHECK(searchBooks({}, "anything", "").empty());

    // JSON output
    CHECK(booksToJson({}) == "[]");
    Book quoted{9, "Say \"Hi\"", "A", "1", "Fiction", false};
    const std::string json = booksToJson({quoted});
    CHECK(json.find("Say \\\"Hi\\\"") != std::string::npos);
    CHECK(json.find("\"is_available\":false") != std::string::npos);

    if (failures == 0) {
        std::cout << "All search tests passed.\n";
        return EXIT_SUCCESS;
    }
    std::cerr << failures << " test(s) failed.\n";
    return EXIT_FAILURE;
}
