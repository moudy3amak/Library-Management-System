# Search Book: khotowat el shoghl (3ala branch `feature/4-search-book`)

El branch beta3ak 3andoh el rename (`javascript.js`) wel navbar links w script src. Fadel: el search logic + tests + CI.

## 1. Rawwa7 3ala el branch beta3ak
```bash
git fetch origin
git checkout feature/4-search-book
git pull
```

## 2. Copy el files men el zip (public/javascript.js haya3mel overwrite lel adeem)
- src/book_search.hpp, src/book_search.cpp
- tests/test_search.cpp
- Makefile
- .github/workflows/ci.yml
- public/javascript.js   (nafs el esm, feh debounce w escapeHtml a7san)

```bash
make test        # lazem yetba3 "All search tests passed."
```

## 3. Commits (kol wa7da lewa7daha, bel esm beta3ak)
```bash
git add src/book_search.hpp src/book_search.cpp
git commit -m "Add searchBooks function (title, author, isbn, category)"

git add tests/ Makefile
git commit -m "Add unit tests for book search"

git add .github/workflows/ci.yml
git commit -m "Add GitHub Actions workflow to build and run tests"

git add public/javascript.js
git commit -m "Add search debounce and safer escapeHtml"

git push
```

## 4. Issue (e3mel-ha ABL el PR) w e3mel Assignee = enta
"Search Book: implement search by title/author/isbn/category"

## 5. Pull Request
base: `main`, compare: `feature/4-search-book`. Fe el wasf: `Closes #<raqam el issue>`.
Zameelak ye3mel Review w Merge. Shoof tab Actions: lazem akhdar.

## 6. Project board
Repo > Projects > New project > Board: Todo / In Progress / Done.
Add issues, Assignee, Priority, Target date (men 28 Nov li 3 Dec). Milestone: "Phase 1 Demo".

## 7. Teshbek ma3 el server (src/server.cpp)
```cpp
#include "book_search.hpp"
std::string q   = req.get_param_value("search");
std::string cat = req.get_param_value("category");
res.set_content(booksToJson(searchBooks(books, q, cat)), "application/json");
```
